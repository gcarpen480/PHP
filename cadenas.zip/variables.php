<?php

$greeting = 'Hola Mundo!';

echo $greeting;

$_var = '¡Soy una variable con un guion bajo!';
$Var = '¡Soy una variable con una letra mayuscula';
$var = 'Soy una nueva variable';

