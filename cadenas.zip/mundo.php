<?php

echo "!Hola Mundo!\n";

echo "Soy una cadena en una nueva línea\n";

echo "PHP"; echo " Aprendiz\n";