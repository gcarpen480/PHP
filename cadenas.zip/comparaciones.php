<?php

$a = true;
$b = false;

$one = 1;
$two = 2;

$one == $two; // devuelve false

$one != $two; // devuelve true

$one < $two; //  devuelve false

$one > $two; // devueve true

$one <= $two;

$one >= $two;

// Todos los siguiente devuelven true.

1 == 1;

1 == '1';

1 == true;

1 == 1.0;

1 == 1;

// Todas las siguientes devuelven false.

1 === '1';

1 === true;

1 === 1.0;