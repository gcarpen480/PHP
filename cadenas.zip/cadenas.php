<?php

$firstname = 'Joey';
$lastname = 'Johnson';

echo "Jacob\nJones\n";

$firstname = 'Cindy';

echo "$firstname Smith\n";

$firstname = 'Jenny ';
$lastname = 'Medison';

$fullname = $firstname . $lastname;

echo $fullname;