<?php

$a = 1;
$b = 2;

echo $a + $b. "\n";

echo $b - $a. "\n";

echo $a * $b. "\n";

echo $b / $a. "\n";

$mod = 10 % 5;

echo $mod. "\n";

echo 5 ** 2;